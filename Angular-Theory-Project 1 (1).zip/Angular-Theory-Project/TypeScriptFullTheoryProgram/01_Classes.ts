/*(1) What is Class in TS :- A class is a blueprint of an object. 
- Ex :- 

class Car { // Class Name start Capital letter
  name: string; // fields / data members
  year: number;
}

const carObj = new Car(); // Class Object Create /instance of a class
carObj.name = "Ajit Kumar";
carObj.year = 22;
console.log(carObj);

const Obj = new Car(); // Single class to create multiples Objects 
Obj.name = "Ram";
console.log(Obj)

//(or)
class Persons {
  name:string = 'Ajit';
  age:number = 24;
  hobbies:string[] = ['reading','book'];
}
const persons1: Persons = new Persons();
console.log(persons1.name)

//(or) 
class Persons {
  name: string; // As a Referance pass in constructor
  age: number;
  hobbies: string[];

  constructor(name: string, age: number, hobbies: string[]) {
    this.name = name;
    this.age = age;
    this.hobbies = hobbies;
  }
}
const persons1: Persons = new Persons("Ajit", 25, ['reading', 'book']); // Note this data to pass in class used constructor
const persons2: Persons = new Persons("Verifact", 22, ['Red', 'black']);
console.log(persons1 , persons2);

//(or)
class Person {
    name: string;
    age: number;

    constructor(name: string, age: number) {
      this.name = name;
      this.age = age;
    }
    // Method to print person details
    MethodCre() { // Direct Parent class access
      console.log(`Hello, my name is ${this.name} and I am ${this.age} years old.`);
    }
    //(or) MethodCre():string { 
    //   return `Hello, my name is ${this.name} and I am ${this.age} years old.`;
    // }
}
const person1 = new Person('Rama', 30);// Creating an instance of the class
person1.MethodCre();


// Access Modifiers :-
- public :- Can be accessed from anywhere (default if not specified).
- private :- Can only be accessed within the class.
- protected :- Can be accessed within the class and its subclasses. 

// Ex:- 
class Car {
    private model: string;
    protected make: string;
    public year: number;

    constructor(model: string, make: string, year: number) {
      this.model = model;
      this.make = make;
      this.year = year;
    }

    // Method to display car information
    displayInfo() {
      console.log(`${this.year} ${this.make} ${this.model}`);
    }
}
const myCar = new Car('ModelS', 'Tata', 2022);
myCar.displayInfo();
console.log(myCar.make); // Cannot be access directly from outside the class or by derived classes.

// Getter and Setter Methods :- TypeScript supports getter and setter methods to control access to class properties.
// Ex :- 
class Circle {
    private _radius: number;

    constructor(radius: number) {
      this._radius = radius;
    }
    // Getter for radius
    get radius(): number {
      return this._radius;
    }
    // Setter for radius
    set radius(value: number) {
        if (value <= 0) {
          console.log("Radius must be positive.");
        } else {
          this._radius = value;
        }
    }
    // Method to calculate area
    area(): number {
      return Math.PI * this._radius * this._radius;
    }
}
const circle = new Circle(5);
console.log(circle.area());  // 78.53981633974483
circle.radius = 10;  // Using setter
console.log(circle.area());  // 314.1592653589793


(2) Inheritance in TS :- Reusability of code it is known as inheritance.
// Base class (superclass)
class Animal {
  name: string; //Properties

  constructor(name: string) {
    this.name = name;
  }

  speak(): void {
    console.log(`${this.name} makes a sound.`);
  }
}

// Derived class (subclass)
class Dog extends Animal {
  breed: string; // Additional property

  constructor(name: string, breed: string) {
    // Call the constructor of the base class
    super(name);
    this.breed = breed;
  }

  // Overriding the method from Animal
  speak(): void {
    console.log(`${this.name} barks.`);
  }

  // New method specific to Dog
  fetch(): void {
    console.log(`${this.name} is fetching the ball.`);
  }
}
// Create an instance of Dog
const myDog = new Dog('Buddy', 'Golden Retriever');
myDog.speak();  // Output: Buddy barks.
myDog.fetch();  // Output: Buddy is fetching the ball.

//(or)


*/
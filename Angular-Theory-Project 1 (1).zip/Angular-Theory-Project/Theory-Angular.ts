/* 
Project Create in CMD/Terminal Command :- ng new myfirstAngularProject
- ng serve
- Project Run in Terminal :- npm start

(1). What is Angular ? :- 
- Angular is an open-source web application framework developed by Google for building dynamic, single-page applications 
using HTML, CSS, and TypeScript (a superset of JavaScript).

(2). Why Use Angular ? :- Robust Framework , TypeScript Support and Large Community and Ecosystem.

(3). When to Use Angular ? :- 
- Single-Page Applications.
- Complex User Interfaces. 
- Long-Term Projects.

(4). Advantages of Angular ? :-
- Component-Based Architecture.
- Two-Way Data Binding.
- Dependency Injection.
- Powerful Routing.
- Cross-Platform Development.
- Built-In Testing Support.
- Declarative UI.

Note :- 
- A component consists of three things :-
Component Part       	                Details
- A component class	           =>    Handles data and functionality
- An HTML template	           =>    Determines the UI
- Component-specific styles	   =>    Define the look and feel

(5). How to create Component in Angular :- Same like React Components , but Angular com.css,com.html and com.ts main file and write down Logic and code.
- Open PowerShell/vs code Editer and enter the command :- ng generate component test/ng g c AjitComponent

(6). What is Angular Libraries ? :- Same as Redux-Toolkit "React.Js".
- Libraries Create Command :- ng generate library my-library

(7). What is  Component, Templates and Metadata in Angular :- 

(1). Component :- A component is a building block of an Angular application. 
- Class:-  Contains the logic for the component, including properties and methods.
- Template:-  Defines the view associated with the component, specifying what the user sees.
- Styles:-  Optional styles that apply to the template.

Ex:- 
import { Component } from '@angular/core';
@Component({
  selector: 'app-example',
  templateUrl: './example.component.html',
  styleUrls: ['./example.component.css']
})
export class ExampleComponent {
  title = 'Hello, Angular!';
}

(2). Template :- A template is an HTML-like syntax that defines the structure of the view associated with a component.
It can include Angular-specific syntax for binding data and handling events.

(i) Data Binding:- Allows you to display component data in the template and synchronize data between the component and the template.
- Interpolation:- {{ propertyName }}
- Property Binding:- [property]="expression"
- Event Binding:- (event)="handlerMethod()"
- Two-way Binding:- [(ngModel)]="propertyName"

Ex:-

<h1>{{ title }}</h1>
<button (click)="handleClick()">Click me</button>

(3). Metadata :- Metadata provides additional information about the component or module. In Angular, metadata is 
primarily defined using decorators like @Component, @NgModule, etc. It tells Angular how to process the class.

- @Component:- Specifies the selector, template, styles, and other configurations for the component.
- @NgModule:-  Defines a module that groups related components, directives, pipes, and services.

Ex:- 
@Component({
  selector: 'app-example',
  templateUrl: './example.component.html',
  styleUrls: ['./example.component.css'],
  // Additional metadata can be included here
})
export class ExampleComponent { ... }


(8). What is Data Binding in Angular :- Data binding in Angular is a technique that synchronizes data between the component and the template, 
enabling real-time updates between the UI and application logic.

#######  Types of Data Binding in Angular  #######
(i) Interpolation :- Used to display component properties in the template.
- Syntax: {{ expression }}
Ex:- <h1>{{ title }}</h1>

(ii) Property Binding :- Allows you to bind component properties to DOM properties of elements.
- Syntax: [property]="expression"
Ex:- <img [src]="imageUrl">

(iii) Event Binding :- Lets you respond to user events, such as clicks or keyboard inputs.
- Syntax: (event)="handlerMethod()"
Ex:- <button (click)="onClick()">Click me</button>

(iv) Two-Way Data Binding :- Combines property binding and event binding, allowing for the synchronization of data in both directions.
Requires the use of ngModel from the FormsModule.
- Syntax: [(ngModel)]="property"
Ex:- <input [(ngModel)]="username">

Ex:- Example of Data Binding in a Component
import { Component } from '@angular/core';
@Component({
  selector: 'app-example',
  template: `
    <h1>{{ title }}</h1>
    <img [src]="imageUrl">
    <button (click)="changeTitle()">Change Title</button>
    <input [(ngModel)]="username">
    <p>Your name is: {{ username }}</p>
  `
})
export class ExampleComponent {
  title = 'Welcome to Angular!';
  imageUrl = 'path/to/image.jpg';
  username = '';

  changeTitle() {
    this.title = 'Title Changed!';
  }
}


(9). What is Directives :- Directives are classes that allow you to extend the capabilities of HTML by attaching behavior to 
elements in the DOM. They enable you to create reusable components and manipulate the structure or appearance of the DOM dynamically. 
There are three main types of directives in Angular:

1. Component Directives :- These are essentially directives with a template. Every component in Angular is a directive with a view.
Ex :-  Any component created using @Component.

2. Structural Directives :- These directives alter the layout of the DOM by adding or removing elements. They typically begin with an asterisk (*).
Common examples include :- 
- *ngIf :- Conditionally includes an element based on a boolean expression.
- *ngFor :- Iterates over a collection to create a template for each item.
- *ngSwitch :- Conditionally switches between multiple elements.
Ex:- <div *ngIf="isVisible">Content is visible</div>

3. Attribute Directives :- These modify the appearance or behavior of existing elements. They don’t change the structure of the DOM.
Ex:-
- ngClass :- Dynamically adds or removes CSS classes.
- ngStyle :- Dynamically sets inline styles.
- Custom attribute directives can also be created.
Ex:- <p [ngClass]="{'active': isActive}">This paragraph's class will change.</p>


(10).  Angular 17, several new features and improvements have been introduced :-
- Standalone Components
- Improved Reactivity
- Directive Composition API
- Signal API
- Enhanced NgModules
- Improved Error Handling
- Angular CLI Updates

(11). What is Services and Dependency Injection in Angular :-

(i) Services :- Services in Angular are singleton objects that provide specific functionality, such as data retrieval,
business logic, or other reusable operations.
- Creating a Service :- Use the Angular CLI to generate a service :- Command , ng generate service my-service
- Usage :- Services can be injected into components or other services to provide functionality.
- Example Service :-
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root', // Makes the service available throughout the app
})
export class MyService {
  getData() {
    return ['data1', 'data2', 'data3'];
  }
}

(ii). Dependency Injection (DI) :- Dependency Injection is a design pattern used to implement IoC (Inversion of Control). 
In Angular, it allows you to inject services into components or other services, enabling a clean separation of 
concerns and making code easier to test and maintain.

- How Dependency Injection Works :- Angular's injector is responsible for creating instances of services and 
injecting them into components or other services that require them.

- Injecting a Service :- To use a service within a component, you need to inject it through the constructor
Ex :- 
import { Component } from '@angular/core';
import { MyService } from './my-service.service';
@Component({
  selector: 'app-my-component',
  template: `<div *ngFor="let item of data">{{ item }}</div>`,
})
export class MyComponent {
  data: string[];
  constructor(private myService: MyService) {
    this.data = this.myService.getData();
  }
}

(12). What is Components Life Cycle Hooks in Angular :- Component lifecycle hooks are special methods that allow you to tap 
into key events in a component's lifecycle. These hooks can be used to perform actions at specific stages of a component's 
existence, such as initialization, change detection, and destruction.

Ex :- 
import { Component, OnInit, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';
@Component({
  selector: 'app-example',
  template: `<p>Example Component</p>`,
})
export class ExampleComponent implements OnInit, OnChanges, OnDestroy {
  ngOnInit() {
    console.log('ngOnInit: Component initialized');
  }

  ngOnChanges(changes: SimpleChanges) {
    console.log('ngOnChanges: Changes detected', changes);
  }

  ngOnDestroy() {
    console.log('ngOnDestroy: Component will be destroyed');
  }
}

(13). What is Styles Binding in Components Angular :- Style binding allows you to dynamically set the styles of HTML elements based
on the component's properties or expressions. 

- (i) Style Property Binding :- You can bind to specific CSS properties using the [style.property] syntax.
Ex:-
import { Component } from '@angular/core';
@Component({
  selector: 'app-example',
  template: `
    <div [style.color]="textColor">This text is dynamic!</div>
    <button (click)="toggleColor()">Toggle Color</button>
  `,
})
export class ExampleComponent {
  textColor = 'blue';

  toggleColor() {
    this.textColor = this.textColor === 'blue' ? 'red' : 'blue';
  }
}

- (ii) Style Binding with Object Syntax :- You can also bind multiple styles at once using an object.
Ex:-
import { Component } from '@angular/core';
@Component({
  selector: 'app-example',
  template: `
    <div [ngStyle]="{'color': textColor, 'font-size': fontSize + 'px'}">
      Dynamic styles here!
    </div>
    <button (click)="increaseFontSize()">Increase Font Size</button>
  `,
})
export class ExampleComponent {
  textColor = 'green';
  fontSize = 16;

  increaseFontSize() {
    this.fontSize += 2;
  }
}

- (iii) Using ngStyle Directive :- The ngStyle directive allows you to set multiple styles at once 
without using the object syntax directly in the template
Ex:-
import { Component } from '@angular/core';
@Component({
  selector: 'app-example',
  template: `
    <div [ngStyle]="styleObject">Styled with ngStyle!</div>
    <button (click)="updateStyles()">Update Styles</button>
  `,
})
export class ExampleComponent {
  styleObject = {
    color: 'purple',
    'font-weight': 'bold',
  };

  updateStyles() {
    this.styleObject = {
      color: this.styleObject.color === 'purple' ? 'orange' : 'purple',
      'font-weight': this.styleObject['font-weight'] === 'bold' ? 'normal' : 'bold',
    };
  }
}


(14). What is Class Bindings in Angular :- Class binding allows you to dynamically add or remove CSS classes on HTML elements.

Ex:- Single Class Binding :- Use the [class.className] syntax.
import { Component } from '@angular/core';
@Component({
  selector: 'app-class-example',
  template: `
    <div [class.active]="isActive">
      This div's class changes dynamically!
    </div>
    <button (click)="toggleActive()">Toggle Active Class</button>
  `,
  styles: [`
    .active { color: green; font-weight: bold; }
  `]
})
export class ClassExampleComponent {
  isActive = false;

  toggleActive() {
    this.isActive = !this.isActive;
  }
}

Ex:- Multiple Classes :- Use the [ngClass] directive.
import { Component } from '@angular/core';
@Component({
  selector: 'app-class-example',
  template: `
    <div [class.active]="isActive">
      This div's class changes dynamically!
    </div>
    <button (click)="toggleActive()">Toggle Active Class</button>
  `,
  styles: [`
    .active { color: green; font-weight: bold; }
  `]
})
export class ClassExampleComponent {
  isActive = false;

  toggleActive() {
    this.isActive = !this.isActive;
  }
}

(15). What is Routing in Angular 17 :- Angular’s routing module allows you to navigate between different views or components in your application. 
It helps manage the state of your application and provides a way to create a single-page application (SPA) experience.

(1) Configuring and Navigating :-  
- Setting up the Router :- First, you need to import the RouterModule in your main application module
Ex:- 
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'about', component: AboutComponent },
];

@NgModule({
  declarations: [AppComponent, HomeComponent, AboutComponent],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}

- Navigating Between Routes :- You can navigate using <a> tags with the routerLink directive
Ex:- <nav>
  <a routerLink="/">Home</a>
  <a routerLink="/about">About</a>
</nav>
<router-outlet></router-outlet>

(2). Parameterized Routes :- Parameterized routes allow you to pass parameters to your routes. For instance, if you want to display user 
profiles based on their ID, you can define a route like this

Ex:- const routes: Routes = [
  { path: 'user/:id', component: UserProfileComponent },
];

- Accessing Route Parameters :- To access the route parameters in your component, inject ActivatedRoute.
Ex:- 
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-profile',
  template: `<h1>User ID: {{ userId }}</h1>`,
})
export class UserProfileComponent implements OnInit {
  userId!: string;

  constructor(private route: ActivatedRoute) {}

  ngOnInit() {
    this.userId = this.route.snapshot.paramMap.get('id')!;
  }
}

(3). Nested (or) Child Routes :- Nested routes allow you to define routes within other routes, which is useful for creating complex layouts.

- Configuring Nested Routes:-
Ex:- 
const routes: Routes = [
  {
    path: 'products',
    component: ProductsComponent,
    children: [
      { path: '', component: ProductListComponent },
      { path: ':id', component: ProductDetailComponent },
    ],
  },
];

- Using <router-outlet> in Parent Component:- In your ProductsComponent, add a <router-outlet> for the child routes.
Ex:- 
<h1>Products</h1>
<router-outlet></router-outlet>

(4). Router Guards :- Router guards help you control access to routes. You can create guards to check if a user is authenticated.

- Creating an Auth Guard :- 
Ex:- 
import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(): boolean {
    const isAuthenticated = false; // Replace with real authentication check
    if (!isAuthenticated) {
      this.router.navigate(['/login']);
      return false;
    }
    return true;
  }
}

- Using the Auth Guard :- Apply the guard to a route.
Ex:- 
const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
];

(5). Create a 404 Component :- First, create a new component for your 404 error page.
Ex:- 
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ProductsComponent } from './products/products.component';
import { NotFoundComponent } from './not-found/not-found.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'about', component: AboutComponent },
  { path: 'products', component: ProductsComponent },
  { path: '**', component: NotFoundComponent } // Wildcard route for 404
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}


(16). What are decorators in Angular? :- Decorators are a design pattern or functions that define how Angular features work. They are used to make prior modifications to a class, service, or filter. Angular supports four types of decorators,
- Class Decorators
- Property Decorators
- Method Decorators
- Parameter Decorators

(17). Advantages of Angular ? 
- MVC architecture 
- Modules
- Dependency injection

(18). Mager changing in Angular 17 and 18 list ?
- Standalone Components
- New Directive API
- Functional Reactive Forms
- Dynamic Imports for Components
- Enhanced Error Handling 
- New CLI Features

(19). What are Templates in Angular? :- Angular Templates are written with HTML that contains Angular-specific elements and attributes.

(20).  What are Pipes in Angular? :- Pipes are simple functions designed to accept an input value, process, and return as an output, a transformed value in a more technical understanding. Angular supports several built-in pipes.

(21). What is the PipeTransform interface? :- As the name suggests, the interface receives an input value and transforms it into the desired format with a transform() method. It is typically used to implement custom pipes.

(22). What are Promises and Observables in Angular? :- While both the concepts deal with Asynchronous events in Angular, Promises handle one such event at a time while observables handle a sequence of events over some time. 

Promises :- They emit a single value at a time. They execute immediately after creation and are not cancellable. They are Push errors to the child promises. 
Observables :- They are only executed when subscribed to them using the subscribe() method. They emit multiple values over a period of time. They help perform operations like forEach, filter, and retry, among others. They deliver errors to the subscribers. When the unsubscribe() method is called, the listener stops receiving further values.

(23). What is Eager and Lazy loading ? 
- Eager loading is the default module-loading strategy. Feature modules under Eager loading are loaded before the application starts. This is typically used for small size applications.
- Lazy loading dynamically loads the feature modules when there's a demand. This makes the application faster. It is used for bigger applications where all the modules are not required at the start of the application. 

(24). What type of DOM does Angular implement? 
- DOM (Document Object Model) treats an XML or HTML document as a tree structure in which each node is an object representing a part of the document. 
- Angular uses the regular DOM. This updates the entire tree structure of HTML tags until it reaches the data to be updated. However, to ensure that the speed and performance are not affected, Angular implements Change Detection.
- With this, you have reached the end of the article. We highly recommend brushing up on the core concepts for an interview. It’s always an added advantage to write the code in places necessary. 

(25).  Explain components, modules and services in Angular ?
(i) Components :- Components are the fundamental building blocks of Angular applications. Each component controls a portion of the UI and consists of an HTML template, a TypeScript class, and associated styles.
Key Features :- 
- Encapsulation :- Each component encapsulates its logic, view, and styles, promoting reusability.
- Templates :- Define the UI using HTML.
- Class :- Contains properties and methods that control the component's behavior.
- Metadata :- Use decorators (e.g., @Component) to configure the component’s selector, template, and styles.
- Data Binding :- Use property binding, event binding, and two-way binding to connect component data and the view.

Ex:-
import { Component } from '@angular/core';
@Component({
  selector: 'app-example',
  template: `<h1>{{ title }}</h1>`,
  styles: [`h1 { color: green; }`]
})
export class ExampleComponent {
  title = 'Hello, Angular!';
}

(ii) Modules :- Modules are a way to organize an Angular application into cohesive blocks of functionality. Each Angular application has at least one module, the root module, typically named AppModule.
Key Features :-
- NgModule :- Defined using the @NgModule decorator, which specifies metadata about the module.
- Declarations :- Lists the components, directives, and pipes that belong to the module.
- Imports :- Imports other modules that the current module needs.
- Providers :- Registers services that the module can use.
- Bootstrap :- Defines the root component that Angular creates and inserts into the index.html host web page.

Ex:- 
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule],
  bootstrap: [AppComponent]
})
export class AppModule {}

(iii) Services :- Services are reusable classes that encapsulate business logic and data retrieval. They promote code reusability and separation of concerns, allowing components to focus on UI rather than logic.

Key Features :-
- Singleton :- Services are typically provided as singletons, meaning only one instance exists for the entire application or module.
- Dependency Injection :- Angular uses dependency injection to provide service instances to components or other services.
- Business Logic :- Ideal for handling data fetching, logging, or any functionality that should be shared across components.
Ex:-
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root',
})
export class DataService {
  getData() {
    return ['Data 1', 'Data 2', 'Data 3'];
  }
}

(26). What are RxJs in Angular? :- RxJS (Reactive Extensions for JavaScript) is a library for reactive programming using Observables. In Angular, RxJS is extensively used for handling asynchronous data streams, providing powerful tools for managing events, AJAX requests, and more.

Key Features of RxJS in Angular :- 
- Observables :- The core building block of RxJS. Observables represent a stream of data that can be observed over time. They can emit multiple values, unlike Promises, which resolve once.
- Operators :- RxJS provides a rich set of operators that allow you to manipulate and transform data streams. Common operators include map, filter, mergeMap, switchMap, and more.
- Subjects :- A special type of Observable that allows values to be multicasted to many Observers. Subjects are useful for sharing data among multiple components.
- Subscriptions :- You can subscribe to Observables to execute a function whenever the data stream emits a new value. Subscriptions also allow for the handling of errors and completion notifications.
- Pipes :- RxJS operators can be combined using the pipe method, allowing for clean and readable chaining of operations on Observables.
- Angular Integration :- RxJS is integrated into many Angular features, such as:
-- HttpClient :- Returns Observables for HTTP requests, making it easy to work with asynchronous data.
-- Reactive Forms :- Leverages Observables to handle form value changes.
-- Event Handling :- Angular uses Observables for handling events, such as user interactions.

Ex:- 
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root',
})
export class DataService {
  constructor(private http: HttpClient) {}
  getData(): Observable<any[]> {
    return this.http.get<any[]>('https://api.example.com/data').pipe(
      map(response => response.data) // Transforming the response
    );
  }
}

(27). What is transpiling in Angular? :- Transpiling in Angular refers to the process of converting TypeScript code into JavaScript code that 
web browsers can execute. Angular applications are built using TypeScript, a superset of JavaScript that adds static typing and additional 
features to the language. Since browsers can only run JavaScript, the TypeScript code needs to be transpiled into JavaScript before it can 
be executed.
Example of Transpiling :- 
- When you write TypeScript code like this
let message: string = "Hello, Angular!";
console.log(message);

- After transpilation, it may be converted to plain JavaScript
var message = "Hello, Angular!";
console.log(message);

(28). What are HTTP interceptors ? :- HTTP interceptors in Angular are a powerful feature that allows you to intercept and modify HTTP requests and responses before they are handled by the application. They are part of the Angular HttpClient module and provide a way to add functionality such as logging, authentication, error handling, and more.

Key Features of HTTP Interceptors
- Interception of Requests and Responses
- Chaining Interceptors
- Error Handling
- Authentication

(29). Write a code to share data from the Parent to Child Component using Angular ? :- To share data from a parent component to a child component in Angular, you can use the @Input() decorator. This allows the parent component to bind a property to the child component, effectively passing data down.
Ex:- 
Step 1: Create the Parent Component
- ng generate component parent
Step 2: Create the Child Component
- ng generate component child
Step 3: Implement the Child Component
- In the child component (e.g., child.component.ts), define an @Input() property to receive data from the parent:
Ex:- 
import { Component, Input } from '@angular/core';
@Component({
  selector: 'app-child',
  template: `<p>Received from parent: {{ data }}</p>`,
})
export class ChildComponent {
  @Input() data: string | undefined; // Using @Input to receive data from the parent
}

Step 4: Implement the Parent Component
- In the parent component (e.g., parent.component.ts), define a property to hold the data and pass it to the child component
Ex:- 
import { Component } from '@angular/core';
@Component({
  selector: 'app-parent',
  template: `
    <h1>Parent Component</h1>
    <app-child [data]="parentData"></app-child>
  `,
})
export class ParentComponent {
  parentData: string = 'Hello from Parent!'; // Data to pass to the child
}

Step 5: Use the Parent Component
- Finally, include the parent component in your main application template (e.g., app.component.html)
Ex:- <app-parent></app-parent>

(or) Write a code to share data from the  Child to Parent Component using Angular ? :- To share data from a child component to a parent component in Angular, you can use the @Output() decorator along with an EventEmitter. This allows the child component to emit events that the parent component can listen to and respond accordingly.

(30). What is Angular CLI ? :- Angular CLI is a command-line interface tool that helps automate the development workflow, including creating, building, testing, and deploying Angular applications.

(31). What is the difference between Angular and AngularJS ? :-
- Angular :-
- Component-based architecture
- TypeScript
- Designed with mobile support
- Two-way data binding with reactive forms and observables

- AngularJS :- 
- MVC (Model-View-Controller)
- JavaScript
- Limited mobile support
- Two-way data binding with scopes and watchers

(32). 

*/
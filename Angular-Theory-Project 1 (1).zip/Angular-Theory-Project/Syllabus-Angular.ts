/* 
1). Introduction to Angular (yes)
• What is Angular?
• Angular Versions: AngularJS (vs) Angular
• Setup for local development environment
    o Installing NodeJS, NPM
    o Angular CLI
• Develop First Angular program using Angular CLI and Visual Studio Code.

2). Angular Architecture (no)
• Basic Building Blocks of Angular Applications
• Angular Modules and @NgModule decorator

**** Important **** (yes) 
• Angular Libraries
• Component, Templates and Metadata
• Data Binding
• Directives 
• Services and Dependency Injection

3). Displaying Dynamic Data (no)
• Types of Directives
• Template Expressions
• String Interpolation
• Built-In Directives
    o ngIf
    o ngSwitch
    o ngFor
• When to use <ng-container>

4). Angular Components Deep Dive (yes)
• What are Components?
• Components Life Cycle Hooks.

5). Data Binding (yes)
• Binding properties and Interpolation
• One-way Binding / Property Binding
• Event Binding
• Two-way binding with NgModel

6). Styles Binding In Components (Yes)
• Style and Class Bindings
• Using Component Styles
• Special selectors
• Loading Styles into Components

7). Angular Routing (Yes)
• Introduction
• Configuring and Navigating
• Parameterized routes
• Nested (or) Child Routes
• Router Guards & Routing Strategies

//Important
8). Template Driven Forms (Project Create in logIn Register)
• Introduction
• Create the component that controls the form
• Create a template with the initial form layout
• Bind data properties to each form input control with the ngModel two-way data binding syntax
• Add the name attribute to each form input control
• Add custom CSS to provide visual feedback
• Show and hide validation error messages
• Handle form submission with ngSubmit
• Disable the form’s submit button until the form is valid
• Resetting the form.

//Important
9). Reactive Forms ,  (Project Create in logIn Register)
• Reactive Forms Introduction
• More Form Controls
• Form Control Properties
• setValue and patchValue
• Validating Form Elements
• Submitting and Resetting forms
• Observing and Reacting to Form Changes Deccansoft Software Services Angular 7 Syllabus
• Using FormBuilder

10). Working with Pipes (No)
• Built-in Pipes
• Using parameters and chaining Pipes
• Custom Pipes

11). Dependency Injection (No)
• Understanding Dependency Injection
• Understanding DI in Angular Framework

12). Services in Angular (No)
• Building and Injecting Custom Services
• Service using another Service

13). Http Client Service (No)
• HttpClientModule and HttpClient Classes
• Writing Service with Get / Add / Edit / Delete
• Using Service in Component

14). Reactive Extension for JavaScript (No)
• Introduction
• Observable and Observer
• Reactive Operators

15). Angular Modules (No)
• AppModule as Root Module
• Feature modules
• Lazy Loading a Module
• Shared Module

*/

